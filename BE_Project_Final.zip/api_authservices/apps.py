from django.apps import AppConfig


class AuthConfig(AppConfig):
    name = "api_authservices"
