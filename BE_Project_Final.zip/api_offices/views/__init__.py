from api_offices.views.office import OfficeView
from api_offices.views.group import GroupView
