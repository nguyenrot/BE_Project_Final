from api_departments.views.department import DepartmentView
