from api_news.serializers.news import NewsSerializers
