from api_news.views.news import NewsView
