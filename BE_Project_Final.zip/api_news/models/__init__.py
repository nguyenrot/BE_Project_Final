from api_news.models.news import News
