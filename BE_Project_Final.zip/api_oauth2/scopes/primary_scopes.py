primary_scopes = {
    "admin": "super_admin",
}
