from api_oauth2.scopes.primary_scopes import primary_scopes
from api_oauth2.scopes.default_scopes import default_scopes
