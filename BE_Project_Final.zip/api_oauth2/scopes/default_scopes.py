default_scopes = {
    "Employee receive": "employee_receive",
    "Employee approve": "employee_approve",
}
