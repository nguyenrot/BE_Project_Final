default_scopes = {
    "employee": "Employee",
}
