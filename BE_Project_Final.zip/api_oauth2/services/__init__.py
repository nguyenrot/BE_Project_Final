# from .application import ApplicationService
from api_oauth2.services.oauth2 import AuthorizationOauth2
