from api_oauth2.permissions.oauth2_permissions import TokenHasActionScope


class Oauth2Permissions:
    pass
