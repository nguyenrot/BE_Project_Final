from django.apps import AppConfig


class ApiOauth2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api_oauth2'
